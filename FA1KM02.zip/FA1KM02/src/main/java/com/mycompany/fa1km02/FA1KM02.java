/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.fa1km02;

/**
 *
 * @author alpha
 */
public class FA1KM02 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
