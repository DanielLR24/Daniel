public class ScoreCalculator {

    //Version 1: Accepts three integers
    public static double calculateAverage(int a, int b, int c) {
        return (a + b + c) / 3.0;
    }

    //Version 2: Accepts an array of integers
    public static double calculateAverage(int[] scores) {
        if (scores == null || scores.length == 0) {
            throw new IllegalArgumentException("Array must not be null or empty");
        }
        int sum = 0;
        for (int score : scores) {
            sum += score;
        }
        return (double) sum / scores.length;
    }

    public static void main(String[] args) {
        System.out.println("Average of 3 scores: " + calculateAverage(75, 85, 95));
        System.out.println("Average of array: " + calculateAverage(new int[]{60, 70, 80, 90}));
    }
}
