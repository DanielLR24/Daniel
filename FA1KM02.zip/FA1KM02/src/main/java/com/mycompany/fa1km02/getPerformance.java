package com.mycompany.fa1km02;

public class getPerformance {

    public static String getPerformance(double avg) {
        if (avg >= 80) return "Excellent";
        else if (avg >= 50) return "Good";
        else return "Needs Improvement";
    }
}
