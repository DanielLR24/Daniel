import java.util.Scanner;

public class StudentAverage {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double[] scores = new double[3];
        double sum = 0;

        //Input quiz scores with validation
        for (int i = 0; i < 3; i++) {
            while (true) {
                System.out.print("Enter quiz score " + (i + 1) + " (0-100): ");
                
                //Ensure valid numeric input
                if (sc.hasNextDouble()) {
                    scores[i] = sc.nextDouble();
                    if (scores[i] >= 0 && scores[i] <= 100) {
                        break; //Valid input, move to next quiz
                    } else {
                        System.out.println("Invalid score. Please enter a number between 0 and 100.");
                    }
                } else {
                    System.out.println("Invalid input. Please enter a number.");
                    sc.next(); //Clear invalid input
                }
            }
            sum += scores[i];
        }

        double average = sum / scores.length;

        //Formatted output
        System.out.printf("%n Average score: %.2f%n", average);

        sc.close();
    }
}
