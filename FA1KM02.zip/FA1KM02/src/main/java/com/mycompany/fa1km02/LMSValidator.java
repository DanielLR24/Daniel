public class LMSValidator {

    public static boolean validateEmail(String email) {
        return email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$");
    }

    public static void main(String[] args) {
        String testEmail = "student@example.com";

        if (validateEmail(testEmail)) {
            System.out.println("Valid email.");
        } else {
            System.out.println("Invalid email.");
        }
    }
}
