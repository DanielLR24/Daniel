import java.util.Scanner;

public class ClassScores {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        //Create an array to store scores for 10 students
        int[] scores = new int[10]; //Arrays allow us to store multiple values of the same type efficiently
        int sum = 0; //To calculate total for average

        //Input scores with validation
        for (int i = 0; i < scores.length; i++) {
            while (true) {
                System.out.print("Enter score for student " + (i + 1) + " (0–100): ");
                scores[i] = sc.nextInt();
                if (scores[i] >= 0 && scores[i] <= 100) break; //Ensure score is between 0 and 100
                System.out.println("Invalid input. Please enter 0–100.");
            }
            sum += scores[i]; //Add to total for average calculation
        }

        //Calculate class average
        double average = (double) sum / scores.length;

        //Find highest and lowest scores
        int highest = scores[0];
        int lowest = scores[0];
        for (int score : scores) {
            if (score > highest) highest = score; // Update highest if current score is larger
            if (score < lowest) lowest = score;   // Update lowest if current score is smaller
        }

        //Count how many students scored above average
        int aboveCount = 0;
        for (int score : scores) {
            if (score > average) aboveCount++;
        }

        //Display results
        System.out.printf("Class average: %.2f%n", average);
        System.out.println("Highest score: " + highest);
        System.out.println("Lowest score: " + lowest);
        System.out.println("Students above average: " + aboveCount);
    }
}
