package com.mycompany.fa1km02;

public class getHighestScore {

    public static int getHighestScore(int[] scores) {
        if (scores == null) {
            throw new IllegalArgumentException("Scores array cannot be null");
        }
        if (scores.length == 0) {
            throw new IllegalArgumentException("No scores available");
        }

        int max = scores[0];
        for (int score : scores) {
            if (score > max) {
                max = score;
            }
        }

        return max;
    }

    public static void main(String[] args) {
        int[] scores = {78, 92, 85, 100, 67};
        System.out.println("Highest score: " + getHighestScore(scores));
    }
}
