class Student {
    String name;
    int totalScore;

    Student(String name, int totalScore) {
        this.name = name;
        this.totalScore = totalScore;
    }
}

public class StudentRanking {
    public static void bubbleSort(Student[] students) {
        boolean swapped;
        int n = students.length;
        do {
            swapped = false;
            for (int i = 0; i < n - 1; i++) {
                if (students[i].totalScore < students[i + 1].totalScore) {
                    Student temp = students[i];
                    students[i] = students[i + 1];
                    students[i + 1] = temp;
                    swapped = true;
                }
            }
        } while (swapped);
    }

    public static void main(String[] args) {
        Student[] students = {
            new Student("Alice", 60),
            new Student("Sarah", 95),
            new Student("Charlie", 59),
            new Student("Ben", 24)
        };

        bubbleSort(students);

        for (int i = 0; i < students.length; i++) {
            System.out.println((i + 1) + ". " + students[i].name + " - " + students[i].totalScore);
        }
    }
}
