package com.hostio.musicstoreapp;

public class Music {
    //Private attributes for album details
    private String artist;
    private String album;
    private int year;
    private String genre;
    private double price;
    private int quantity;

    //Constructor to initialize attributes
    public Music(String artist, String album, int year, String genre, double price, int quantity) {
        this.artist = artist;
        this.album = album;
        this.year = year;
        this.genre = genre;
        this.price = price;
        this.quantity = quantity;
    }

    //Getter and setter methods for all attributes
    public String getArtist(){return artist;}
    public void setArtist(String artist){this.artist=artist;}

    public String getAlbum(){return album;}
    public void setAlbum(String album){this.album=album;}

    public int getYear(){return year;}
    public void setYear(int year){this.year=year;}

    public String getGenre(){return genre;}
    public void setGenre(String genre){this.genre=genre;}

    public double getPrice(){return price;}
    public void setPrice(double price){this.price=price;}

    public int getQuantity(){return quantity;}
    public void setQuantity(int quantity){this.quantity=quantity;}

    //Method to handle sales and calculate total price
    public double sellMusic(int qty){
        if(qty<=0){
            System.out.println("Invalid quantity entered!");
            return 0;
        }
        if(qty>quantity){
            System.out.println("Only "+quantity+" copies available. Selling remaining stock...");
            double total=price*quantity;
            quantity=0;
            return total;
        }else{
            quantity-=qty;
            return price*qty;
        }
    }

    //Method to format display of album details
    @Override
    public String toString(){
        return String.format("%-20s %-25s %-6d %-15s R%-6.2f Qty:%d",
                artist, album, year, genre, price, quantity);
    }
}
