
package com.hostio.musicstoreapp;

import java.io.*;
import java.util.*;

public class MusicMain {
    //List to store all music records
    private static ArrayList<Music> stockList=new ArrayList<>();
    private static double totalSales=0;

    public static void main(String[] args){
        //Step 1: Load data from stock.txt
        loadStockFile();

        //Step 2: Display menu
        Scanner sc=new Scanner(System.in);
        int choice;

        do{
            System.out.println("\n==== MUSIC STORE MENU ====");
            System.out.println("1. List All Stock");
            System.out.println("2. Sell Music");
            System.out.println("3. Show Out of Stock");
            System.out.println("4. Show Total Sales");
            System.out.println("5. Save & Exit");
            System.out.print("Enter your choice: ");
            
            //Error handling for menu input
            while(!sc.hasNextInt()){
                System.out.println("Invalid input! Please enter a number between 1-5.");
                sc.next();
            }
            choice=sc.nextInt();
            sc.nextLine();

            switch(choice){
                case 1->listAll();
                case 2->processSale(sc);
                case 3->showOutOfStock();
                case 4->System.out.println("Total Sales so far: R"+String.format("%.2f",totalSales));
                case 5->{
                    saveStockFile();
                    System.out.println("Data saved successfully. Exiting...");
                }
                default->System.out.println("Invalid option! Try again.");
            }
        }while(choice!=5);
        sc.close();
    }

    //Loads data from text file into ArrayList
    private static void loadStockFile(){
        try(BufferedReader br=new BufferedReader(new FileReader("stock.txt"))){
            String line;
            br.readLine(); //skip header
            while((line=br.readLine())!=null){
                String[] parts=line.split(",");
                if(parts.length==6){
                    String artist=parts[0];
                    String album=parts[1];
                    int year=Integer.parseInt(parts[2]);
                    String genre=parts[3];
                    double price=Double.parseDouble(parts[4]);
                    int qty=Integer.parseInt(parts[5]);
                    stockList.add(new Music(artist,album,year,genre,price,qty));
                }
            }
            System.out.println("Stock loaded successfully.");
        }catch(FileNotFoundException e){
            System.out.println("File not found! Please ensure stock.txt exists.");
        }catch(IOException e){
            System.out.println("Error reading file: "+e.getMessage());
        }
    }

    //Display all albums in stock
    private static void listAll(){
        System.out.println("\n--- FULL STOCK LIST ---");
        for(Music m:stockList){
            System.out.println(m);
        }
    }

    //Process sale for selected album
    private static void processSale(Scanner sc){
        System.out.print("Enter album name to sell: ");
        String albumName=sc.nextLine().trim();
        Music found=null;

        for(Music m:stockList){
            if(m.getAlbum().equalsIgnoreCase(albumName)){
                found=m;
                break;
            }
        }

        if(found==null){
            System.out.println("Album not found!");
            return;
        }

        System.out.print("Enter quantity to sell: ");
        while(!sc.hasNextInt()){
            System.out.println("Invalid input! Enter a number.");
            sc.next();
        }
        int qty=sc.nextInt();
        sc.nextLine();

        double total=found.sellMusic(qty);
        totalSales+=total;
        System.out.println("Sale completed. Amount: R"+String.format("%.2f",total));
    }

    //Show all albums that are out of stock
    private static void showOutOfStock(){
        System.out.println("\n--- OUT OF STOCK ITEMS ---");
        boolean anyOut=false;
        for(Music m:stockList){
            if(m.getQuantity()==0){
                System.out.println(m);
                anyOut=true;
            }
        }
        if(!anyOut){
            System.out.println("All albums currently in stock.");
        }
    }

    //Save updated stock back to file
    private static void saveStockFile(){
        try(PrintWriter pw=new PrintWriter(new FileWriter("stock.txt"))){
            pw.println("Artist,Album,Year,Genre,Price,Quantity");
            for(Music m:stockList){
                pw.printf("%s,%s,%d,%s,%.2f,%d%n",
                        m.getArtist(),m.getAlbum(),m.getYear(),
                        m.getGenre(),m.getPrice(),m.getQuantity());
            }
        }catch(IOException e){
            System.out.println("Error writing to file: "+e.getMessage());
        }
    }
}
