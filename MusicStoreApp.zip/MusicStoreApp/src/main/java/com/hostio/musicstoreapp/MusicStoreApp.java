/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.hostio.musicstoreapp;

/**
 *
 * @author alpha
 */
public class MusicStoreApp {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
