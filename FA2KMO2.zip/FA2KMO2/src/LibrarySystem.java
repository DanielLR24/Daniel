import java.util.*;
import java.io.*;

public class LibrarySystem {
    public static void main(String[] args) {
        LibraryManager manager = new LibraryManager();
        manager.run();
    }
}

//Base Class and Subclasses
//Base Book class
abstract class Book {
    private int id;
    private String title;
    private String author;
    private int year;
    private String category;

    public Book(int id, String title, String author, int year, String category) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.year = year;
        this.category = category;
    }

    //Getters only, no setters since books don't change
    public int getId() { return id; }
    public String getTitle() { return title; }
    public String getAuthor() { return author; }
    public int getYear() { return year; }
    public String getCategory() { return category; }

    public abstract void displayDetails();
}

//EBook class with file size
class EBook extends Book {
    private int fileSize;
    public EBook(int id, String t, String a, int y, String c, int f) {
        super(id, t, a, y, c);
        this.fileSize = f;
    }
    @Override
    public void displayDetails() {
        System.out.println("[EBook] " + getTitle() + " (" + getYear() + ")");
        System.out.println(" Author: " + getAuthor());
        System.out.println(" Category: " + getCategory());
        System.out.println(" File Size: " + fileSize + "MB\n");
    }
}

//PrintedBook with hardcover info
class PrintedBook extends Book {
    private boolean hardcover;
    public PrintedBook(int id, String t, String a, int y, String c, boolean h) {
        super(id, t, a, y, c);
        this.hardcover = h;
    }
    @Override
    public void displayDetails() {
        System.out.println("[Printed Book] " + getTitle() + " (" + getYear() + ")");
        System.out.println(" Author: " + getAuthor());
        System.out.println(" Category: " + getCategory());
        System.out.println(" Hardcover: " + (hardcover ? "Yes" : "No") + "\n");
    }
}

//Extra subclass for polymorphism example
class AudioBook extends Book {
    private double lengthHours;
    public AudioBook(int id, String t, String a, int y, String c, double l) {
        super(id, t, a, y, c);
        this.lengthHours = l;
    }
    @Override
    public void displayDetails() {
        System.out.println("[AudioBook] " + getTitle() + " (" + getYear() + ")");
        System.out.println(" Author: " + getAuthor());
        System.out.println(" Category: " + getCategory());
        System.out.println(" Length: " + lengthHours + " hours\n");
    }
}

//Manager Class
class LibraryManager {
    //Used LinkedList since we insert or remove often
    private LinkedList<Book> books = new LinkedList<>();
    private Stack<Book> undoStack = new Stack<>();
    private Stack<Book> redoStack = new Stack<>();
    private Scanner sc = new Scanner(System.in);

    public void run() {
        while (true) {
            printMenu();
            try {
                int choice = Integer.parseInt(sc.nextLine());
                switch (choice) {
                    case 1: addBook(); break;
                    case 2: removeBook(); break;
                    case 3: viewBooks(); break;
                    case 4: sortBooks(); break;
                    case 5: searchBook(); break;
                    case 6: undo(); break;
                    case 7: redo(); break;
                    case 8: exportToFile(); break;
                    case 9: System.out.println("Goodbye"); return;
                    default: System.out.println("Invalid choice."); 
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private void printMenu() {
        System.out.println("\n--- LIBRARY MENU ---");
        System.out.println("1. Add Book");
        System.out.println("2. Remove Book");
        System.out.println("3. View All Books");
        System.out.println("4. Sort Books (QuickSort vs MergeSort)");
        System.out.println("5. Search Book by Title");
        System.out.println("6. Undo Last Add");
        System.out.println("7. Redo Last Undo");
        System.out.println("8. Export Library to File");
        System.out.println("9. Exit");
        System.out.print("Enter choice: ");
    }

    //Book Management
    private void addBook() {
        System.out.println("Choose Type: 1=EBook, 2=Printed, 3=AudioBook");
        int type = Integer.parseInt(sc.nextLine());
        int id = readInt("ID: ");
        String title = readLine("Title: ");
        String author = readLine("Author: ");
        int year = readInt("Year: ");
        String cat = readLine("Category: ");

        Book b;
        if (type == 1) {
            int size = readInt("File Size MB: ");
            b = new EBook(id, title, author, year, cat, size);
        } else if (type == 2) {
            boolean hc = readLine("Hardcover? (y/n): ").equalsIgnoreCase("y");
            b = new PrintedBook(id, title, author, year, cat, hc);
        } else {
            double len = Double.parseDouble(readLine("Length (hours): "));
            b = new AudioBook(id, title, author, year, cat, len);
        }
        books.add(b); //Add to main list
        undoStack.push(b); //Track for undo
        redoStack.clear(); //Can't redo after new add
        System.out.println("Book added!");
    }

    private void removeBook() {
        int id = readInt("Enter ID to remove: ");
        books.removeIf(b -> b.getId() == id); //Simple remove
        System.out.println("Removed (if existed).");
    }

    private void viewBooks() {
        if (books.isEmpty()) System.out.println("No books.");
        else for (Book b : books) b.displayDetails(); //Polymorphism here
    }

    //Undo/Redo
    private void undo() {
        if (undoStack.isEmpty()) { System.out.println("Nothing to undo."); return; }
        Book last = undoStack.pop();
        books.remove(last);
        redoStack.push(last);
        System.out.println("Undo: removed " + last.getTitle());
    }

    private void redo() {
        if (redoStack.isEmpty()) { System.out.println("Nothing to redo."); return; }
        Book b = redoStack.pop();
        books.add(b);
        undoStack.push(b);
        System.out.println("Redo: restored " + b.getTitle());
    }

    //Sorting & Searching
    private void sortBooks() {
        if (books.isEmpty()) { System.out.println("No books."); return; }
        Book[] arr1 = books.toArray(new Book[0]);
        Book[] arr2 = books.toArray(new Book[0]);

        //QuickSort
        long t1 = System.nanoTime();
        int comp1 = SortUtil.quickSort(arr1, 0, arr1.length - 1);
        long t2 = System.nanoTime();

        //MergeSort
        long t3 = System.nanoTime();
        int comp2 = SortUtil.mergeSort(arr2, 0, arr2.length - 1);
        long t4 = System.nanoTime();

        System.out.printf("QuickSort: %.3f ms, %d comparisons\n", (t2 - t1) / 1e6, comp1);
        System.out.printf("MergeSort: %.3f ms, %d comparisons\n", (t4 - t3) / 1e6, comp2);

        books = new LinkedList<>(Arrays.asList(arr1)); //Update list with sorted
        System.out.println("Books sorted by QuickSort order.");
    }

    private void searchBook() {
        if (books.isEmpty()) { System.out.println("No books."); return; }
        String q = readLine("Enter title keyword: ").toLowerCase();
        Book[] arr = books.toArray(new Book[0]);
        int idx = SortUtil.binarySearch(arr, q);
        if (idx >= 0) {
            System.out.println("Found:");
            arr[idx].displayDetails();
        } else System.out.println("Not found.");
    }

    //Export
    private void exportToFile() {
        try (PrintWriter pw = new PrintWriter(new FileWriter("library_export.txt"))) {
            for (Book b : books) {
                pw.println(b.getTitle() + " by " + b.getAuthor());
            }
            System.out.println("Exported to library_export.txt");
        } catch (IOException e) {
            System.out.println("Export failed: " + e.getMessage());
        }
    }

    //Input Helpers
    private int readInt(String msg) {
        System.out.print(msg);
        return Integer.parseInt(sc.nextLine());
    }
    private String readLine(String msg) {
        System.out.print(msg);
        return sc.nextLine();
    }
}

//Sorting Utils
class SortUtil {
    public static int quickSort(Book[] arr, int low, int high) {
        int comps = 0;
        if (low < high) {
            int[] res = partition(arr, low, high);
            comps += res[1];
            int pi = res[0];
            comps += quickSort(arr, low, pi - 1);
            comps += quickSort(arr, pi + 1, high);
        }
        return comps;
    }

    private static int[] partition(Book[] arr, int low, int high) {
        String pivot = arr[high].getTitle().toLowerCase();
        int i = low - 1, comps = 0;
        for (int j = low; j < high; j++) {
            comps++;
            if (arr[j].getTitle().toLowerCase().compareTo(pivot) <= 0) {
                i++;
                swap(arr, i, j);
            }
        }
        swap(arr, i + 1, high);
        return new int[]{i + 1, comps};
    }

    public static int mergeSort(Book[] arr, int l, int r) {
        int comps = 0;
        if (l < r) {
            int m = (l + r) / 2;
            comps += mergeSort(arr, l, m);
            comps += mergeSort(arr, m + 1, r);
            comps += merge(arr, l, m, r);
        }
        return comps;
    }

    private static int merge(Book[] arr, int l, int m, int r) {
        int comps = 0;
        int n1 = m - l + 1, n2 = r - m;
        Book[] L = new Book[n1];
        Book[] R = new Book[n2];
        System.arraycopy(arr, l, L, 0, n1);
        System.arraycopy(arr, m + 1, R, 0, n2);

        int i = 0, j = 0, k = l;
        while (i < n1 && j < n2) {
            comps++;
            if (L[i].getTitle().compareToIgnoreCase(R[j].getTitle()) <= 0)
                arr[k++] = L[i++];
            else arr[k++] = R[j++];
        }
        while (i < n1) arr[k++] = L[i++];
        while (j < n2) arr[k++] = R[j++];
        return comps;
    }

    private static void swap(Book[] arr, int i, int j) {
        Book tmp = arr[i]; arr[i] = arr[j]; arr[j] = tmp;
    }

    public static int binarySearch(Book[] arr, String key) {
        int l = 0, r = arr.length - 1;
        while (l <= r) {
            int mid = (l + r) / 2;
            String title = arr[mid].getTitle().toLowerCase();
            if (title.contains(key)) return mid; //Partial match allowed
            if (title.compareTo(key) < 0) l = mid + 1;
            else r = mid - 1;
        }
        return -1;
    }
}
