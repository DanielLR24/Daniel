class BankAccount {
    private double balance;  //private variable

    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;   //only valid deposits allowed
        }
    }

    public double getBalance() {
        return balance;
    }
}
