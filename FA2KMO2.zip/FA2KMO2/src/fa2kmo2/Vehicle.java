class Vehicle {
    void startEngine() {
        System.out.println("Starting generic engine...");
    }
}

class Motorcycle extends Vehicle {
    @Override
    void startEngine() {
        System.out.println("Starting motorcycle engine!");
    }
}

public class TestDrive {
    public static void main(String[] args) {
        Vehicle myBike = new Motorcycle(); //superclass reference, subclass object
        myBike.startEngine();               //Output: Starting motorcycle engine!
    }
}
