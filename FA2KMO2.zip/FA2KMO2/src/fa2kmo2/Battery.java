class Battery {
    void charge() { System.out.println("Charging battery"); }
}

class ElectricCar {
    private Battery battery;          //ElectricCar has a Battery

    ElectricCar(Battery battery) {
        this.battery = battery;
    }

    void startCar() {
        battery.charge();
        System.out.println("Car is ready!");
    }
}
